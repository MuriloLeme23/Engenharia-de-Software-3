package br.com.fatec;



public class DescontoPorcentagem implements ValorDesconto {
	private double descontoporcentagem;;


	public double desconto(Produto produto, Desconto desconto) {
		this.descontoporcentagem = desconto.getValorDesconto();
		descontoporcentagem = descontoporcentagem / 100;
	
		return descontoporcentagem * produto.getValorProduto();
	}
	
	

}
