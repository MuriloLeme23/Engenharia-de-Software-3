package br.com.fatec;

import java.util.ArrayList;
import java.util.List;

public class Execucao {
	public static void main(String[] args) {
		Desconto desconto = new Desconto(100);
		Produto p1 = new ProdutoUnitario("NoteBook", 2500, desconto);
		Produto p2 = new ProdutoUnitario("MouseWireless", 230, desconto);

		List<Produto> produtos = new ArrayList<>();
		produtos.add(p1);
		produtos.add(p2);

		Produto kit = new ProdutoComposto("Kit de inform�tica", produtos);

		Sistema sis = new Sistema();
		sis.valorDeCobranca(p1);
		
		
		
		
		
		
	}

}
