package br.com.fatec;

public abstract class Produto {
	protected String nome;
	protected double valorProduto;
	public Desconto desconto;
	private CalculadorPreco calculadorPreco;




	public String getNome() {
		return nome;
	}

	public double getValorProduto() {
		return valorProduto;
	}

	public double getValorComDesconto() {
		calculadorPreco = new CalculadorPreco(this);
		return calculadorPreco.calcularDescontos();
	}
}