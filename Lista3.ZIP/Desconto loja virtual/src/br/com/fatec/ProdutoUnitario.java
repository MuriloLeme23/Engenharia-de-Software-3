package br.com.fatec;

public class ProdutoUnitario extends Produto {
	
	public ProdutoUnitario(String nome, double valorProduto, Desconto desconto) {
		super();
		this.nome=nome;
		this.valorProduto = valorProduto;
		this.desconto= desconto;
	}

}
