package br.com.fatec;

public class DescontoDinheiro implements ValorDesconto{
	public double descontodinheiro;
	
	
	public DescontoDinheiro(double descontodinheiro) {
		this.descontodinheiro = descontodinheiro;
	}
	@Override
	
	
	public double desconto(Produto produto, Desconto desconto) {
		this.descontodinheiro = desconto.getValorDesconto();
		return descontodinheiro - produto.getValorProduto() ;
	}

}
