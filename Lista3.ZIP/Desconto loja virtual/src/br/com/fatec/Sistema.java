package br.com.fatec;

public class Sistema {
	public void valorDeCobranca(Produto p) {
		System.out.println("O valor do produto para, com desconto: R$ " + 
				p.getValorComDesconto());
	}
	
	
}