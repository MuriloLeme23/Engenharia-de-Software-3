package br.com.fatec;

import java.util.ArrayList;
import java.util.List;

public class ProdutoComposto extends Produto {

	private List<Produto> produtos = new ArrayList<>();

	
	public ProdutoComposto(String nome, List<Produto> produtos) {
		super();
		this.nome=nome;
		this.produtos.addAll(produtos);
		calcularValorTotal();
		calcularDescontoTotal();
	}


	private void calcularValorTotal() {
		double valorTotal = valorProduto;
		for (Produto p : produtos) {
			valorTotal = valorTotal + p.getValorProduto();
		}
		valorProduto = valorTotal;
	}

	private void calcularDescontoTotal() {
		double valorDescontos = 0;
		for (Produto p : produtos) {
			valorDescontos = valorDescontos +
					p.desconto.getValorDesconto();
		}
		desconto = new Desconto(valorDescontos);
	}
}