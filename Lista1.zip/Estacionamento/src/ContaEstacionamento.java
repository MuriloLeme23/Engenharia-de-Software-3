
public class ContaEstacionamento {
	private Calculovalor calculo;
	private Veiculo veiculo;
	private long inicio;
	private long fim;

	
	public double valorConta() {
		return calculo.valorConta(fim-inicio, veiculo);
		
		
	}
	
	
	public void setCalculo(Calculovalor calculo) {
		this.calculo=calculo;
	}
	
		
	}
		
	
	
		
	


