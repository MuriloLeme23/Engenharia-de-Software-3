
public class Carga extends Veiculo{
	
}
