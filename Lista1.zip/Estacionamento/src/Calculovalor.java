
public interface Calculovalor{
	
	double valorConta(long periodo, Veiculo veiculo);
	
	}
	

