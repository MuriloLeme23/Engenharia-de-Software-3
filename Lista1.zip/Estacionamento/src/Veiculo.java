
public class Veiculo{
	

}
