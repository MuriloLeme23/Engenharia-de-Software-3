package br.com.fatec;

public class Desconto {
	private double valorDesconto;

	public Desconto(double valorDesconto) {
		this.valorDesconto = valorDesconto;
	}

	public double getValorDesconto() {
		return valorDesconto;
	}
}