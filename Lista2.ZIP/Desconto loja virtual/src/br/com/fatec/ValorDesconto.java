package br.com.fatec;

public interface ValorDesconto {
	public double desconto(Produto produto, Desconto desconto);

}
