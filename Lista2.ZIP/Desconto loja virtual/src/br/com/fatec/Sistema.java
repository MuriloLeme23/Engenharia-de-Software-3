package br.com.fatec;

public class Sistema {
	public static void main(String[] args) {
		Desconto desconto = new Desconto(100);
		Produto p1 = new Produto("NoteBook", 2500, desconto);
		System.out.println("O valor do produto para, com desconto: R$ " 
		+ p1.getValorComDesconto());
	}
}