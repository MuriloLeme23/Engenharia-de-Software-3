package br.com.fatec;

public class CalculadorPreco {
	private Produto produto;
	private ValorDesconto calculo;
	private Desconto desconto;

	public CalculadorPreco(Produto produto) {
		this.produto = produto;
	}

	public double calcularDescontos() {
		return calculo.desconto(produto, desconto);
	}
}