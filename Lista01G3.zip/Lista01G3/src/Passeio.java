
public class Passeio extends Veiculo {

}
