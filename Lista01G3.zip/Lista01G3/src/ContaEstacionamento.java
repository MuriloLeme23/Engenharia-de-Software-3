
public class ContaEstacionamento {
	private Calculovalor calculo;
	private double veiculo;
	private long inicio;
	private long fim;

	
	public double valorConta() {
		return calculo.valorConta(fim-inicio, veiculo);
		
		
	}
	
	
	public void setCalculo(Calculovalor calculo) {
		this.calculo=calculo;
	}
	
	ContaEstacionamento(){
		
	}
		
	}
	
		
	


