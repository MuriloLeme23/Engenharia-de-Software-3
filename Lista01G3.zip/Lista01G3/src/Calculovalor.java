
public interface Calculovalor{
	
	double valorConta(long periodo, double veiculo);
	
	}
	

