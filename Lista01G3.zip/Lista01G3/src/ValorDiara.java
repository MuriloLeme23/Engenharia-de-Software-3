
public class ValorDiara implements Calculovalor {
	private double valordiaria=48;
	private double DIA;
	private double HORA;
	
	public ValorDiara (double valordiaria) {
		this.valordiaria=valordiaria;
	}

	@Override
	public double valorConta(long periodo, double veiculo) {
		if(periodo>12*HORA && periodo<15*DIA) {
			valordiaria = valordiaria * Math.ceil(periodo/DIA);
		}
		return valordiaria;
	}

	
	} 