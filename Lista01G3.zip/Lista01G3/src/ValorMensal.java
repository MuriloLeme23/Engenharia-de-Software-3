
public class ValorMensal implements Calculovalor {
	public double MES;
	private double valormes=1440;

	
	
	public ValorMensal (double valormes) {
		this.valormes=valormes;
	}

	@Override
	public double valorConta(long periodo, double veiculo) {
			if(periodo>15*MES) {
				valormes = valormes * Math.ceil(periodo/MES);
			}
			return valormes;
			
			
	}

	
	}