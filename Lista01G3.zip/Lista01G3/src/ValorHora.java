
public class ValorHora implements Calculovalor {
	public double HORA;
	public double valorhora=2;
	
	
	public ValorHora (double valorhora) {
		this.valorhora=valorhora;
	}

	@Override
	public double valorConta(long periodo, double veiculo) {
			if(periodo<12*HORA) {
				valorhora = valorhora * Math.ceil(periodo/HORA);
			}
			return valorhora;

	}

	
	}

	
